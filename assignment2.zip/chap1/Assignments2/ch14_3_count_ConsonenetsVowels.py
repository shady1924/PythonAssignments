import sys
import os.path

## /Users/sharadagnihotri/Documents/workspace/chap1/Assignments2/ch8_ex2_CheckSubStrings.py

def main():
    keywords={ "import", "open", "input", "for", ":", "readline","range", "if", "and", "def"}
    filname=input("Enter the name of the file:").strip()
#     filname="/Users/sharadagnihotri/Documents/workspace/chap1/Assignments2/ch11_10_largestrws_cols.py"
    if not os.path.isfile(filname):
        print("file does not exists")
        sys.exit()    
    infile=open(filname, "r")

    wrdcnt={}
    for lin in infile.readlines():

             
        lindict= set(lin.split())
        
        for i in (lindict & keywords):
            if i in wrdcnt:
                wrdcnt[i] +=1
            else:
                wrdcnt[i] =1

    print(wrdcnt)
    infile.close()
    
main()