'''
for i in range(1980,2017):
    for j in range(1,19) :
        print("i="+ str(i)+ "j is: " + str(j))
    print ("ending value for " + str(i))
'''

for i in range(1900,2017):
    if i%12 == 8:
        print("i values is ", i )
    else: 
        continue
