## ch 1.4  print line doing power operation for from 1 to 4 without using loop
print ("a\ta^2\ta^3")
print ( str(1 ** 1) + "\t" + str(1 ** 2) + "\t" + str(1 ** 3) )
print ( str(2 ** 1) + "\t" + str(2 ** 2) + "\t" + str(2 ** 3) )
print ( str(3 ** 1) + "\t" + str(3 ** 2) + "\t" + str(3 ** 3) )
print ( str(4 ** 1) + "\t" + str(4 ** 2) + "\t" + str(4 ** 3) )

