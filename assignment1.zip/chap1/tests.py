import random
'''
print (format(12312324.2342342, '30.3f') )

print('%10s' % ('test',))

print("/" + '{:<10}'.format('test') + "/" )

print("/" + format(57,'50.2%' ) + "/")
print("/" + format(0.573242340,'<50.2%' ) + "/")

print("/" + format (22342342,'<x') +"/"   )

print(format ( 31 ,'b') )

print (format(int('11111',2)))



print( int(5.1**2) )
print( int(5**2) )

#print(format (9.75,"$0.2f") )

print('{0}{1}'.format('$', '9.75', ' ') )
'''

rand1 = random.randint(100,999)   
src=rand1
lastdigit1 = src%10
remaindernum= src//10

src=remaindernum
lastdigit2 = src%10 
remaindernum= src//10 

src=remaindernum
lastdigit3 = src%10 
remaindernum= src//10
 

'''
LotteryDigit= int(rand1/10)
LotteryDigit1= rand1-(LotteryDigit*10)
print("last digit", LotteryDigit1 , "remaining number", LotteryDigit )

LotteryDigit= int(LotteryDigit/10)
LotteryDigit2= LotteryDigit-(LotteryDigit*10)
print("last digit", LotteryDigit2 , "remaining number", LotteryDigit )

LotteryDigit= int(LotteryDigit1/10)
LotteryDigit2= rand1- (LotteryDigit*10)
print("LotteryDigit1:", LotteryDigit1, " remainder" , LotteryDigit2 ) 
''' 