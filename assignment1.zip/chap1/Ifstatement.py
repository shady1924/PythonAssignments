coloFlag=True
for i in range(1,10):
    coloFlag= not coloFlag    
    print(coloFlag)
